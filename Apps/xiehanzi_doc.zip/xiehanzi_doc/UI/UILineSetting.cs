﻿ 
    public  int LINE_WIDTH_PIXSEL_MAX = 900;//  2048x1536
     
