﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


using Mono.Data.Sqlite;
using System.IO;
using System.Data;

public class DBWord : MonoBehaviour
{
    public const string WORD_TABLE_NAME = "table_word";
    DBTool dbTool;

    public string dbFilePath
    {
        get
        {
            string dbfilename = "DBWord.sqlite";
            string appDBPath = Application.temporaryCachePath + "/" + dbfilename;
            // if (Application.platform == RuntimePlatform.WindowsEditor)//如果是windows编辑器中

            // {

            //     appDBPath = Application.dataPath + "//" + dbfilename;

            // }
            // else if (Application.platform == RuntimePlatform.Android)//--如果是安卓平台

            // {

            //     appDBPath = Application.persistentDataPath + "/" + dbfilename;

            //     // if (!File.Exists(appDBPath))

            //     // {

            //     //     WWW loader = new WWW("jar:file://" + Application.dataPath + "/" + connectionString);//把数据库复制到安卓可写路径中，注：sqlite不能在安装包中读取数据

            //     //     File.WriteAllBytes(appDBPath, loader.bytes);

            //     // }

            // }
            return appDBPath;
        }
    }
    static  DBWord _main = null;
    static bool isInited = false;
    public static DBWord main
    {
        get
        {
            if (!isInited)
            {
                isInited = true;
                _main = new DBWord();
                Debug.Log("DBWord main init");
                _main.CreateDb();
            }
            return _main;
        }

        
        //ng:
        //  get
        // {
        //     if (_main==null)
        //     {
        //         _main = new DBWord();
        //         Debug.Log("DBWord main init");
        //         _main.CreateDb();
        //     }
        //     return _main;
        // }
    }

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    void CreateDb()
    {
        dbTool = new DBTool();
        OpenDB();
         string[] item_col = new string[] { "id", "filesave", "date", "addtime" };
        string[] item_coltype = new string[] { "text", "text", "text", "text" };

     if (!dbTool.IsExitTable(WORD_TABLE_NAME))
        {
            dbTool.CreateTable(WORD_TABLE_NAME, item_col, item_coltype);
        }
        
        CloseDB();
    }

    void OpenDB()
    {


        dbTool.OpenDB(dbFilePath);
   
        //   string[] item_col = new string[] { "id,filesave,date,addtime" };
        //   string[] item_coltype = new string[] { "string,string,string,string" };

       
    }

    void CloseDB()
    {
        dbTool.CloseDB();
    }

    //2017.1.10 to 1.10
    static public string getDateDisplay(string date)
    {
        int idx = date.IndexOf(".");
        if (idx >= 0)
        {
            string str = date.Substring(idx + 1);
            return str;
        }
        return date;
    }
    public void AddItem(WordItemInfo info)
    {
        OpenDB();
        string[] values = new string[4];
        //id,filesave,date,addtime
        values[0] = info.id;
        values[1] = info.fileSaveWord;
        //values[2] = info.id;
        //values[3] = info.id;
        int year = System.DateTime.Now.Year;
        int month = System.DateTime.Now.Month;
        int day = System.DateTime.Now.Day;
        string str = year + "." + month + "." + day;
        Debug.Log("date:" + str);
        values[2] = str;
        long time_sconde = Common.GetCurrentTimeSecond();
        values[3] = time_sconde.ToString();
        dbTool.InsertInto(WORD_TABLE_NAME, values);

        CloseDB();
        //  GetItemsByWord();


    }

    void ReadInfo(WordItemInfo info, SqliteDataReader rd)
    {
       // Debug.Log("ReadInfo");
        string id = rd.GetString(rd.GetOrdinal("id"));
       // Debug.Log(id);
        string filesave = rd.GetString(rd.GetOrdinal("filesave"));
       // Debug.Log(filesave);
        string date = rd.GetString(rd.GetOrdinal("date"));
       //  Debug.Log(date);
        string addtime = rd.GetString(rd.GetOrdinal("addtime"));
       //  Debug.Log(addtime);
        info.id = id;
        info.fileSaveWord = filesave;
        info.addtime = addtime;
        info.date = date;
    }


    public List<WordItemInfo> GetAllWord()
    {
        // Distinct 去掉重复
        //desc 降序 asc 升序 
        string strsql = "select DISTINCT id from " + WORD_TABLE_NAME + " order by addtime desc";

        List<WordItemInfo> listRet = new List<WordItemInfo>();
        OpenDB();
        //SqliteDataReader reader = dbTool.ReadFullTable(WORD_TABLE_NAME);//
        SqliteDataReader reader = dbTool.ExecuteQuery(strsql);
        while (reader.Read())// 循环遍历数据 
        {
            WordItemInfo info = new WordItemInfo();
            info.id = reader.GetString(reader.GetOrdinal("id"));
            listRet.Add(info);
        }

        reader.Close();

        CloseDB();
        return listRet;
    }

    public List<WordItemInfo> GetAllDate()
    {
        // Distinct 去掉重复
        //desc 降序 asc 升序 
        string strsql = "select DISTINCT date from " + WORD_TABLE_NAME + " order by addtime desc";

        List<WordItemInfo> listRet = new List<WordItemInfo>();
        OpenDB();
        SqliteDataReader reader = dbTool.ExecuteQuery(strsql);
        while (reader.Read())// 循环遍历数据 
        {
            WordItemInfo info = new WordItemInfo();
            info.date = reader.GetString(reader.GetOrdinal("date"));
            listRet.Add(info);
        }

        reader.Close();

        CloseDB();
        return listRet;
    }

    public List<WordItemInfo> GetItemsOfDate(string date)
    {
        string strsql = "select * from " + WORD_TABLE_NAME + " where date = '" + date + "'" + "order by addtime desc";
        List<WordItemInfo> listRet = new List<WordItemInfo>();
        OpenDB();

        SqliteDataReader reader = dbTool.ExecuteQuery(strsql);
        while (reader.Read())// 循环遍历数据 
        {
            WordItemInfo info = new WordItemInfo();
            ReadInfo(info, reader);
            listRet.Add(info);
        }

        reader.Close();

        CloseDB();
        return listRet;
    }


    public List<WordItemInfo> GetItemsOfWord(string word)
    {
        string strsql = "select * from " + WORD_TABLE_NAME + " where id = '" + word + "'" + "order by addtime desc";
        List<WordItemInfo> listRet = new List<WordItemInfo>();
        OpenDB();
        //"select * from %s where keyZi = \"%s\" order by addtime desc"
        SqliteDataReader reader = dbTool.ExecuteQuery(strsql);
        while (reader.Read())// 循环遍历数据 
        {
            WordItemInfo info = new WordItemInfo();
            ReadInfo(info, reader);
            listRet.Add(info);
        }

        reader.Close();

        CloseDB();
        return listRet;
    }

}
