﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 
using Vectrosity;

public class UIBgWrite : UIView
{
    public UISprite uiBg;
    public UISprite uiBoard;
    public UISprite ui;
    /// <summary>
    /// Awake is called when the script instance is being loaded.
    /// </summary>
    void Awake()
    { 
        
    }
    // Use this for initialization
    void Start()
    {
        Vector2 size = uiBoard.GetBoundSize();
        Debug.Log("UIBgWrite GetBoundSize size="+size);
        LayOut();
    }

    /// <summary>
    /// This function is called when the MonoBehaviour will be destroyed.
    /// </summary>
    void OnDestroy()
    {
       
    }
 

    public override void LayOut()
    {
        base.LayOut();
        LayOutScale ly = uiBoard.GetComponent<LayOutScale>();
        float ofty = Common.CanvasToWorldHeight(mainCam,AppSceneBase.main.sizeCanvas,160f);
        // ly.offsetMax = new Vector2(0,ofty);
        // ly.offsetMin = new Vector2(0,ofty);
        // float z = uiBoard.gameObject.transform.localPosition.z;
        // uiBoard.gameObject.transform.localPosition = new Vector3(0,ofty/2,z);
        ly.LayOut();
        base.LayOut();
    }
 
     public Vector2 GetBoundBoard()
    { 
        return uiBoard.GetBoundSize();
    }
}
