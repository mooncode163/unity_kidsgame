﻿
using System.Collections;
using System.Collections.Generic;
using LitJson;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ItemInfoLearnSound : ItemInfo
{
    public string picInner;
    public string picOuter;
    public Color color;
    public bool isMain;//主要项
    public bool isInner;
    public string colorid;
    public List<object> listColorFilter;

}

public class UIGameLearnSound : UIGameBase
{
    public const string AUDIO_FALL_DOWN = "Audio/fall_down";

    public const string STR_GAME_GUIDE_GUESS = "STR_GAME_GUIDE_GUESS";//小朋友,这是谁的声音啊，把它找出来吧
    public const string STR_GAME_FAIL_GUESS = "STR_GAME_FAIL_GUESS";//再试试看吧
    public const string STR_GAME_SUCCESSFULL_GUESS = "STR_GAME_SUCCESSFULL_GUESS";//真聪明，这是xxx的声音
    public const int GAME_MODE_LEARN = 0;
    public const int GAME_MODE_GUESS = 1;

    public const int TAG_ITEM_LOCK = -1;
    public const int TAG_ITEM_UNLOCK = 0;

    public GameObject objTopBar;
    public GameObject objSpriteBall;
    public GameObject objSpritePic;
    public GameObject objSpritePic1;
    public ParticleSystem particleMusic;

    public Image imageTopBar;
    public Text textTitle;
    public Button btnBack;
    public Button btnPre;
    public Button btnNext;
    public Button btnSwitch;
    string strPlace;

    List<object> listItem;
    bool isItemHasSel;
    Vector2 ptDownScreen;
    Vector3 posItemWorld;
    float itemPosZ = -20f;

    AudioClip audioClipItemFinish;
    ActionRotation360 actionRotation360;
    GameObject objSpritePicClick;
    string answerItemId;//
    Vector3 ballPosNormal;

    ItemInfoLearnSound infoOther;
    int randomIndexGuess;

    bool isSpeekGameGuide;
    bool isTTSSpeakTitle;
    void Awake()
    {

        isSpeekGameGuide = false;
        isTTSSpeakTitle = false;
        AppSceneBase.main.UpdateWorldBg(AppRes.IMAGE_GAME_BG);
        //  audioClipItemFinish = (AudioClip)Resources.Load(AppResAudio.RES_AUDIO_PINTU_BLOCK_FINISH);


        InitLanguage();
        ParseGuanka();
    }


    // Use this for initialization
    void Start()
    {
        bool ret = Common.GetBool(AppString.STR_KEY_BACKGROUND_MUSIC);
        if (ret)
        {
            //不播放背景音乐
            AudioPlay.main.Stop();
        }
        UpdateGuankaLevel(GameManager.gameLevel);

    }

    // Update is called once per frame 
    void Update()
    {
        /* 
        // DoConvertImage();
        // mobile touch
        if ((Input.touchCount > 0))
        {
            switch (Input.touches[0].phase)
            {
                case TouchPhase.Began:
                    onTouchDown();
                    break;

                case TouchPhase.Moved:
                    onTouchMove();
                    break;

                case TouchPhase.Ended:
                    onTouchUp();
                    break;

            }
        }


        //pc mouse
        //#if UNITY_EDITOR
        if ((Input.touchCount == 0))
        {
            if (Input.GetMouseButtonUp(0))
            {
                onTouchUp();
            }



            if (Input.GetMouseButtonDown(0))
            {
                //  Debug.Log("Input:" + Input.mousePosition);
                onTouchDown();
            }


            if (Input.GetMouseButton(0))
            {
                onTouchMove();
            }

        }
*/

        if (Input.GetKeyUp(KeyCode.Escape))
        {
            OnClickBtnBack();
        }
    }

    /// <summary>
    /// This function is called when the MonoBehaviour will be destroyed.
    /// </summary>
    void OnDestroy()
    {

    }

    public override void UpdateGuankaLevel(int level)
    {
        AppSceneBase.main.ClearMainWorld();
        objSpriteBall = new GameObject("ball");
        objSpriteBall.AddComponent<SpriteRenderer>();
        //ball
        {
            actionRotation360 = objSpriteBall.AddComponent<ActionRotation360>();
            actionRotation360.duration = 4.0f;
        }
        AppSceneBase.main.AddObjToMainWorld(objSpriteBall);

        objSpritePic = new GameObject("pic");
        objSpritePic1 = new GameObject("pic1");
        objSpritePic.AddComponent<SpriteRenderer>();
        objSpritePic1.AddComponent<SpriteRenderer>();
        AppSceneBase.main.AddObjToMainWorld(objSpritePic);
        AppSceneBase.main.AddObjToMainWorld(objSpritePic1);

        {
            UITouchEvent ev = objSpritePic.AddComponent<UITouchEvent>();
            ev.callBackTouch = OnUITouchEvent;
        }

        {
            UITouchEvent ev = objSpritePic1.AddComponent<UITouchEvent>();
            ev.callBackTouch = OnUITouchEvent;
        }
        {
            UITouchEvent ev = objSpriteBall.AddComponent<UITouchEvent>();
            ev.callBackTouch = OnUITouchEvent;
        }

        LoadGame(gameMode);
        //必须在LoadGame之后执行
        if (gameMode == GAME_MODE_LEARN)
        {
            UpdateTitle();
        }


        LayOutChild();

        ShowAdInsert(GAME_AD_INSERT_SHOW_STEP);
    }

    static public void InitLanguage()
    {
        if (languageGame != null)
        {
            languageGame.SetLanguage(Language.main.GetLanguage());
            return;
        }
        languageGame = new Language();
        languageGame.Init(Common.GAME_RES_DIR + "/language/language.csv");
        languageGame.SetLanguage(Language.main.GetLanguage());
    }

    void onTouchDown()
    {


        isItemHasSel = false;
        Vector2 pos = Common.GetInputPosition();
        ptDownScreen = pos;

        Vector3 posword = mainCam.ScreenToWorldPoint(pos);
        Debug.Log("onTouchDown: " + posword);

        Bounds bd = objSpritePic.GetComponent<SpriteRenderer>().bounds;

        posword.z = bd.center.z;
        Rect rc = new Rect(objSpritePic.transform.position.x - bd.size.x / 2, objSpritePic.transform.position.y - bd.size.y / 2, bd.size.x, bd.size.y);
        //Debug.Log("left:"+bd+"rc="+rc);
        if (rc.Contains(posword))
        {

            isItemHasSel = true;

        }
    }
    void onTouchMove()
    {
        if (!isItemHasSel)
        {
            //Debug.Log("onTouchMove ng 1");
            return;
        }

        // float x, y, w, h;
        // Vector2 pos = Common.GetInputPosition();

        // Vector2 ptStep = pos - ptDownScreen;
        // Vector2 ptStepWorld = Common.ScreenToWorldSize(mainCam, ptStep);
        // Vector3 posStepWorld = new Vector3(ptStepWorld.x, ptStepWorld.y, 0);
        // Vector3 posword = posItemWorld + posStepWorld;

        // //将选中item暂时置顶
        // posword.z = itemPosZ - 1;
        // itemInfoSel.obj.transform.localPosition = posword;


        // foreach (ShapeColorItemInfo info in listItem)
        // {
        //     isLock = IsItemLock(info);
        //     if (isLock)
        //     {
        //         //  Debug.Log("onTouchMove ng 3");
        //         // continue;
        //     }

        //     if (info == itemInfoSel)
        //     {
        //         continue;
        //     }
        //     Bounds bd = info.obj.GetComponent<SpriteRenderer>().bounds;

        //     posword.z = bd.center.z;
        //     w = bd.size.x / 4;
        //     h = bd.size.y / 4;
        //     Rect rc = new Rect(info.obj.transform.position.x - w / 2, info.obj.transform.position.y - h / 2, w, h);
        //     //Debug.Log("left:"+bd+"rc="+rc);
        //     if ((rc.Contains(posword)) && (itemInfoSel.id == info.id) && (itemInfoSel.color == info.color))
        //     {
        //         Debug.Log("合并正确");


        //         break;
        //     }
        // }

        // CheckGameWin();

    }
    void onTouchUp()
    {
        if (!isItemHasSel)
        {
            return;
        }

        if (gameMode == GAME_MODE_LEARN)
        {
            PlayItemSound();
        }
    }


    void LayOutChild()
    {



    }


    public void OnUITouchEvent(UITouchEvent ev, PointerEventData eventData, int status)
    {
        GameObject obj = ev.gameObject;
        if (gameMode == GAME_MODE_LEARN)
        {
            return;
        }
        switch (status)
        {
            case UITouchEvent.STATUS_TOUCH_DOWN:
                break;
            case UITouchEvent.STATUS_TOUCH_MOVE:
                if (obj == objSpriteBall)
                {
                    actionRotation360.Pause();
                }

                break;
            case UITouchEvent.STATUS_TOUCH_UP:
                {
                    if ((obj == objSpritePic) || (obj == objSpritePic1))
                    {
                        actionRotation360.Pause();
                        objSpritePicClick = obj;
                        Vector3 posTarget = obj.transform.position;
                        posTarget.z = ballPosNormal.z;
                        iTween.MoveTo(objSpriteBall, iTween.Hash("position", posTarget, "time", 1f, "oncompletetarget", this.gameObject, "oncomplete", "MoveAnimationEnd"));

                    }

                    if (obj == objSpriteBall)
                    {
                        bool is_in_rect = false;
                        bool ret = IsBallInRectOfPic(objSpritePic);
                        if (ret)
                        {
                            is_in_rect = true;
                            objSpritePicClick = objSpritePic;
                            CheckGameWin();
                        }
                        else
                        {
                            ret = IsBallInRectOfPic(objSpritePic1);
                            if (ret)
                            {
                                is_in_rect = true;
                                objSpritePicClick = objSpritePic1;
                                CheckGameWin();
                            }
                        }

                        if (!is_in_rect)
                        {
                            ShowGameFailAnimate();
                        }
                    }

                }
                break;
        }


    }

    bool IsBallInRectOfPic(GameObject obj)
    {
        bool ret = false;
        Vector3 posword = objSpriteBall.transform.position;
        Bounds bd = obj.GetComponent<SpriteRenderer>().bounds;
        posword.z = bd.center.z;
        Rect rc = new Rect(obj.transform.position.x - bd.size.x / 2, obj.transform.position.y - bd.size.y / 2, bd.size.x, bd.size.y);

        if (rc.Contains(posword))
        {
            ret = true;
        }
        return ret;
    }

    void StartMoveAnimationEnd()
    {
        objSpritePic.SetActive(true);
        objSpritePic1.SetActive(true);
        PlayItemSound();
    }
    void MoveAnimationEnd()
    {
        CheckGameWin();
    }

    void UpdateTitle()
    {
        isTTSSpeakTitle = true;
        int idx = GameManager.gameLevel;
        ItemInfo info = listGuanka[idx] as ItemInfo;
        string str = languageGame.GetString(info.id);
        textTitle.text = str;
        int fontsize = textTitle.fontSize;
        float str_w = Common.GetStringLength(str, AppString.STR_FONT_NAME, fontsize);
        RectTransform rctran = imageTopBar.transform as RectTransform;
        Vector2 sizeDelta = rctran.sizeDelta;
        float oft = 0;
        sizeDelta.x = str_w + fontsize + oft * 2;
        rctran.sizeDelta = sizeDelta;
        TTS.Speek(str);

    }

    ItemInfoLearnSound GetItemInfoOther()
    {
        ItemInfoLearnSound info = GetItemInfo();
        if (info == null)
        {
            return null;
        }
        int rdm = Random.Range(0, listGuanka.Count - 1);
        int index = 0;
        for (int i = 0; i < listGuanka.Count; i++)
        {
            ItemInfoLearnSound infotmp = listGuanka[i] as ItemInfoLearnSound;
            if (infotmp.id != info.id)
            {
                if (index == rdm)
                {
                    return infotmp;
                }
                index++;
            }
        }
        return null;
    }
    ItemInfoLearnSound GetItemInfo()
    {
        int idx = GameManager.gameLevel;
        if (listGuanka == null)
        {
            return null;
        }
        if (idx >= listGuanka.Count)
        {
            return null;
        }
        ItemInfoLearnSound info = listGuanka[idx] as ItemInfoLearnSound;
        return info;
    }

    public override int GetGuankaTotal()
    {
        int count = ParseGuanka();
        return count;
    }

    public override void CleanGuankaList()
    {
        if (listGuanka != null)
        {
            listGuanka.Clear();
        }

    }

    public override int ParseGuanka()
    {
        int count = 0;
        if ((listGuanka != null) && (listGuanka.Count != 0))
        {
            return listGuanka.Count;
        }

        listGuanka = new List<object>();
        int idx = GameManager.placeLevel;
        string fileName = Common.GAME_RES_DIR + "/guanka/guanka_list_place" + idx + ".json";
        //FILE_PATH
        string json = FileUtil.ReadStringAsset(fileName);//((TextAsset)Resources.Load(fileName, typeof(TextAsset))).text;
        // Debug.Log("json::"+json);
        JsonData root = JsonMapper.ToObject(json);
        strPlace = (string)root["place"];
        JsonData items = root["items"];
        for (int i = 0; i < items.Count; i++)
        {
            JsonData item = items[i];
            ItemInfoLearnSound info = new ItemInfoLearnSound();
            info.id = (string)item["id"];

            string picdir = Common.GAME_RES_DIR + "/image/" + strPlace;
            info.pic = picdir + "/" + info.id + ".png";


            string icondir = Common.GAME_RES_DIR + "/image_thumb/" + strPlace;
            info.icon = icondir + "/" + info.id + ".png";

            //sfx_accordion_1.mp3
            info.sound = "App/Audio/sound_effects/sfx_" + info.id + "_1";
            listGuanka.Add(info);
        }

        count = listGuanka.Count;

        Debug.Log("ParseGame::count=" + count);
        return count;
    }


    void SetItemLock(ItemInfo info, bool isLock)
    {
        if (isLock)
        {
            info.tag = TAG_ITEM_LOCK;
        }
        else
        {
            info.tag = TAG_ITEM_UNLOCK;
        }
    }
    bool IsItemLock(ItemInfo info)
    {
        bool ret = false;
        if (info.tag == TAG_ITEM_LOCK)
        {
            ret = true;
        }
        return ret;
    }

    void PlayItemSound()
    {
        ItemInfoLearnSound info = null;

        if (GAME_MODE_LEARN == gameMode)
        {
            info = GetItemInfo();
        }

        if (GAME_MODE_GUESS == gameMode)
        {

            if (randomIndexGuess == 0)
            {
                info = GetItemInfo();
            }
            else
            {
                info = infoOther;
            }
        }

        if (info == null)
        {
            return;
        }
        answerItemId = info.id;
        AudioClip audioClip = (AudioClip)Resources.Load(info.sound);
        GameObject audioPlayer = GameObject.Find("AudioPlayer");
        if (audioPlayer != null)
        {
            AudioSource audioSource = audioPlayer.GetComponent<AudioSource>();
            audioSource.PlayOneShot(audioClip);

            if (gameMode == GAME_MODE_GUESS)
            {
                if (!isSpeekGameGuide)
                {
                    StopCoroutine("SpeekGameGuide");
                    StartCoroutine("SpeekGameGuide", audioClip.length);
                }
                StopCoroutine("PlayItemSoundEnd");
                StartCoroutine("PlayItemSoundEnd", audioClip.length + 2.0f);
            }
        }

    }

    public IEnumerator SpeekGameGuide(float delaySeconds)
    {
        yield return new WaitForSeconds(delaySeconds);

        if (!isSpeekGameGuide)
        {
            isSpeekGameGuide = true;
            TTS.Speek(Language.main.GetString(STR_GAME_GUIDE_GUESS));
        }
    }

    public IEnumerator PlayItemSoundEnd(float delaySeconds)
    {
        yield return new WaitForSeconds(delaySeconds);
        PlayItemSound();

    }
    float GetSystemBarHeight(float y)
    {
        float h = 0;
        if (y < 0)
        {
            h = Common.ScreenToWorldHeight(mainCam, Device.heightSystemHomeBar);
        }
        else
        {
            h = Common.ScreenToWorldHeight(mainCam, Device.heightSystemTopBar);
        }
        return h;
    }
    void LoadGame(int mode)
    {
        Debug.Log("LoadGame:mode=" + mode);
        Vector2 sizeCanvas = AppSceneBase.main.sizeCanvas;
        switch (mode)
        {
            case GAME_MODE_LEARN:
                {

                    textTitle.gameObject.SetActive(true);
                    imageTopBar.gameObject.SetActive(true);
                    btnSwitch.gameObject.SetActive(false);

                    btnPre.gameObject.SetActive(true);
                    btnNext.gameObject.SetActive(true);
                    objSpriteBall.SetActive(false);
                    objSpritePic1.SetActive(false);

                    particleMusic.gameObject.SetActive(false);

                }

                break;
            case GAME_MODE_GUESS:
                {

                    textTitle.gameObject.SetActive(false);
                    imageTopBar.gameObject.SetActive(false);
                    btnSwitch.gameObject.SetActive(true);

                    btnPre.gameObject.SetActive(false);
                    btnNext.gameObject.SetActive(false);
                    objSpriteBall.SetActive(true);
                    objSpritePic1.SetActive(true);

                    particleMusic.gameObject.SetActive(true);

                }
                break;
        }
        if (listItem != null)
        {
            listItem.Clear();
        }
        else
        {
            listItem = new List<object>();
        }

        infoOther = GetItemInfoOther();
        randomIndexGuess = Random.Range(0, 2);

        ItemInfoLearnSound info = GetItemInfo();
        if (GAME_MODE_LEARN == mode)
        {
            float ratio_rect = 0.7f;
            SpriteRenderer objSR = objSpritePic.GetComponent<SpriteRenderer>();
            if (info == null)
            {
                Debug.Log("placeLevel=" + GameManager.placeLevel + "  gameLevel=" + GameManager.gameLevel);
            }
            objSR.sprite = LoadTexture.CreateSprieFromAsset(info.pic);
            objSpritePic.transform.position = new Vector3(0, 0, itemPosZ);
            Vector2 world_size = Common.ScreenToWorldSize(mainCam, new Vector2(Screen.width, Screen.height));
            float oftx = Common.CanvasToWorldWidth(mainCam, sizeCanvas, 160 * 2);
            float ofty = Common.CanvasToWorldHeight(mainCam, sizeCanvas, 160 * 2);
            float h_systembar = 0;
            if (Device.isLandscape)
            {
                h_systembar = Common.ScreenToWorldHeight(mainCam, Device.heightSystemHomeBar);
            }
            else
            {
                h_systembar = Common.ScreenToWorldHeight(mainCam, Mathf.Max(Device.heightSystemHomeBar, Device.heightSystemTopBar));
            }
            ofty += h_systembar * 2;
            float w_disp_rect = (world_size.x - oftx) * ratio_rect; ;
            float h_disp_rect = (world_size.y - ofty) * ratio_rect; ;
            float scalex = w_disp_rect / objSR.size.x;
            float scaley = h_disp_rect / objSR.size.y;
            //Debug.Log("sprite.texw="+sprite.texture.width+" texh="+sprite.texture.height+" sprite.size="+objSR.size+" oftx="+oftx+" ofty="+ofty);
            float scale = Mathf.Min(scalex, scaley);
            objSpritePic.transform.localScale = new Vector3(scale, scale, 1f);

            Vector3 scaleto = new Vector3(scale * 0.95f, scale * 0.95f, 1f);
            iTween.ScaleTo(objSpritePic, iTween.Hash("scale", scaleto, "time", 1.0f, "looptype", iTween.LoopType.pingPong, "easetype", iTween.EaseType.easeInOutSine));
        }

        if (GAME_MODE_GUESS == mode)
        {
            float ratio_rect = 0.7f;
            if (!Device.isLandscape)
            {
                ratio_rect = 0.85f;
            }
            int rdm = Random.Range(0, 2);
            bool is_show_left = false;
            if (rdm == 0)
            {
                is_show_left = true;
            }
            Vector2 world_size = Common.ScreenToWorldSize(mainCam, new Vector2(Screen.width, Screen.height));
            float x_pic = 0;
            float y_pic = 0;
            if (is_show_left)
            {
                x_pic = -world_size.x / 4;
                y_pic = -world_size.y / 4;
            }
            else
            {
                x_pic = world_size.x / 4;
                y_pic = world_size.y / 4;
            }
            //left
            {
                SpriteRenderer objSR = objSpritePic.GetComponent<SpriteRenderer>();
                if (info == null)
                {
                    Debug.Log("place =" + GameManager.placeLevel + " level=" + GameManager.gameLevel);
                }
                //  objSR.sprite = LoadTexture.CreateSprieFromAsset(info.icon);
                Texture2D tex = TextureCache.main.Load(info.icon);
                objSR.sprite = LoadTexture.CreateSprieFromTex(tex);
                BoxCollider box = objSpritePic.AddComponent<BoxCollider>();
                box.size = new Vector2(tex.width / 100, tex.height / 100);

                objSpritePic.transform.position = new Vector3(0, 0, itemPosZ);
                objSpritePic.name = info.id;
                float scale = 1f;
                if (Device.isLandscape)
                {
                    //left
                    float oftx = Common.CanvasToWorldWidth(mainCam, sizeCanvas, 160 * 2);
                    oftx += GetSystemBarHeight(1f) * 2;
                    float ofty = Common.CanvasToWorldHeight(mainCam, sizeCanvas, 160 * 2);
                    float w_disp_rect = (world_size.x / 2 - oftx) * ratio_rect;
                    float h_disp_rect = (world_size.y - ofty) * ratio_rect;
                    float scalex = w_disp_rect / objSR.size.x;
                    float scaley = h_disp_rect / objSR.size.y;
                    //Debug.Log("sprite.texw="+sprite.texture.width+" texh="+sprite.texture.height+" sprite.size="+objSR.size+" oftx="+oftx+" ofty="+ofty);
                    scale = Mathf.Min(scalex, scaley);
                    objSpritePic.transform.position = new Vector3(x_pic, 0, itemPosZ);

                }
                else
                {
                    //top
                    float oftx = Common.CanvasToWorldWidth(mainCam, sizeCanvas, 160 * 2);
                    float ofty = Common.CanvasToWorldHeight(mainCam, sizeCanvas, 160 * 2);
                    ofty += GetSystemBarHeight(y_pic) * 2;
                    float w_disp_rect = (world_size.x - oftx) * ratio_rect;
                    float h_disp_rect = (world_size.y / 2 - ofty) * ratio_rect;
                    float scalex = w_disp_rect / objSR.size.x;
                    float scaley = h_disp_rect / objSR.size.y;
                    //Debug.Log("sprite.texw="+sprite.texture.width+" texh="+sprite.texture.height+" sprite.size="+objSR.size+" oftx="+oftx+" ofty="+ofty);
                    scale = Mathf.Min(scalex, scaley);
                    objSpritePic.transform.position = new Vector3(0, y_pic, itemPosZ);
                }


                objSpritePic.transform.localScale = new Vector3(scale, scale, 1f);


                Vector3 scaleto = new Vector3(scale * 0.95f, scale * 0.95f, 1f);
                iTween.ScaleTo(objSpritePic, iTween.Hash("scale", scaleto, "time", 0.8f, "looptype", iTween.LoopType.pingPong, "easetype", iTween.EaseType.easeInOutSine));

            }

            //ohter right 
            if (infoOther != null)
            {
                SpriteRenderer objSR1 = objSpritePic1.GetComponent<SpriteRenderer>();
                Texture2D tex = TextureCache.main.Load(infoOther.icon);
                objSR1.sprite = LoadTexture.CreateSprieFromTex(tex);
                BoxCollider box = objSpritePic1.AddComponent<BoxCollider>();
                box.size = new Vector2(tex.width / 100, tex.height / 100);

                objSpritePic1.transform.position = new Vector3(0, 0, itemPosZ);
                objSpritePic1.name = infoOther.id;
                float scale = 1f;
                if (Device.isLandscape)
                {
                    float oftx = Common.CanvasToWorldWidth(mainCam, sizeCanvas, 160 * 2);
                    oftx += GetSystemBarHeight(1f) * 2;
                    float ofty = Common.CanvasToWorldHeight(mainCam, sizeCanvas, 160 * 2);
                    float w_disp_rect = (world_size.x / 2 - oftx) * ratio_rect;
                    float h_disp_rect = (world_size.y - ofty) * ratio_rect;
                    float scalex = w_disp_rect / objSR1.size.x;
                    float scaley = h_disp_rect / objSR1.size.y;
                    //Debug.Log("sprite.texw="+sprite.texture.width+" texh="+sprite.texture.height+" sprite.size="+objSR.size+" oftx="+oftx+" ofty="+ofty);
                    scale = Mathf.Min(scalex, scaley);
                    objSpritePic1.transform.position = new Vector3(-x_pic, 0, itemPosZ);
                }
                else
                {
                    //
                    float oftx = Common.CanvasToWorldWidth(mainCam, sizeCanvas, 160 * 2);
                    float ofty = Common.CanvasToWorldHeight(mainCam, sizeCanvas, 160 * 2);
                    ofty += GetSystemBarHeight(-y_pic) * 2;
                    float w_disp_rect = (world_size.x - oftx) * ratio_rect;
                    float h_disp_rect = (world_size.y / 2 - ofty) * ratio_rect;
                    float scalex = w_disp_rect / objSR1.size.x;
                    float scaley = h_disp_rect / objSR1.size.y;
                    //Debug.Log("sprite.texw="+sprite.texture.width+" texh="+sprite.texture.height+" sprite.size="+objSR.size+" oftx="+oftx+" ofty="+ofty);
                    scale = Mathf.Min(scalex, scaley);
                    objSpritePic1.transform.position = new Vector3(0, -y_pic, itemPosZ);
                }


                objSpritePic1.transform.localScale = new Vector3(scale, scale, 1f);

                Vector3 scaleto = new Vector3(scale * 0.95f, scale * 0.95f, 1f);
                iTween.ScaleTo(objSpritePic1, iTween.Hash("scale", scaleto, "time", 1.0f, "looptype", iTween.LoopType.pingPong, "easetype", iTween.EaseType.easeInOutSine));
            }

            //ball
            {
                SpriteRenderer objSRBall = objSpriteBall.GetComponent<SpriteRenderer>();
                Texture2D tex = TextureCache.main.Load("App/UI/Game/BtnBall");
                objSRBall.sprite = LoadTexture.CreateSprieFromTex(tex);
                ballPosNormal = new Vector3(0, 0, itemPosZ - 1);
                BoxCollider box = objSpriteBall.AddComponent<BoxCollider>();
                box.size = new Vector2(tex.width / 100, tex.height / 100);
                float scale = 0.7f;
                if (!Device.isLandscape)
                {
                    scale = 0.5f;
                }
                objSpriteBall.transform.localScale = new Vector3(scale, scale, 1f);
                objSpriteBall.transform.position = new Vector3(0, mainCam.orthographicSize + objSRBall.bounds.size.y / 2, itemPosZ - 1); ;
                objSpritePic.SetActive(false);
                objSpritePic1.SetActive(false);
                PlaySoundFromResource(AUDIO_FALL_DOWN);
                iTween.MoveTo(objSpriteBall, iTween.Hash("position", ballPosNormal, "time", 0.8f, "easeType", iTween.EaseType.easeOutBounce, "oncompletetarget", this.gameObject, "oncomplete", "StartMoveAnimationEnd"));
            }

        }


    }



    void CheckGameWin()
    {
        if (objSpritePicClick == null)
        {
            return;
        }
        Debug.Log("CheckGameWin answerItemId=" + answerItemId + " objSpritePicClick.name=" + objSpritePicClick.name);
        if (answerItemId == objSpritePicClick.name)
        {
            //答案正确
            string str = Language.main.GetString(STR_GAME_SUCCESSFULL_GUESS);
            string stritem = languageGame.GetString(answerItemId);
            //Debug.Log("STR_GAME_SUCCESSFULL_GUESS:"+str+" stritem="+stritem);
            str = str.Replace("xxx", stritem);
            //Debug.Log(str);
            TTS.Speek(str);
            OnGameWin();
        }
        else
        {
            TTS.Speek(Language.main.GetString(STR_GAME_FAIL_GUESS));
            ShowGameFailAnimate();

        }

    }
    public void ShowGameFailAnimate()
    {
        //答案错误
        iTween.MoveTo(objSpriteBall, iTween.Hash("position", ballPosNormal, "time", 1f, "easeType", iTween.EaseType.easeInQuint));
    }

    public void OnGameWin()
    {
        //show game win
        GameManager.gameLevelFinish = GameManager.gameLevel;
        //gameEndParticle.Play();

        //记录游戏完成
        int level = GameManager.gameLevel;


        //Invoke("ShowGameWin", 1f);
        ShowGameWin();
    }

    void ShowUserGuide()
    {


        string pkey = AppString.STR_KEY_USER_GUIDE + Common.GetAppVersion();
        bool isshowplay = Common.GetBool(pkey);
        if (isshowplay == true)
        {
            return;
        }


        {
            string title = Language.main.GetString(AppString.STR_UIVIEWALERT_TITLE_USER_GUIDE);
            string msg = Language.main.GetString(AppString.STR_UIVIEWALERT_MSG_USER_GUIDE);
            string yes = Language.main.GetString(AppString.STR_UIVIEWALERT_YES_USER_GUIDE);
            string no = yes;
            ViewAlertManager.main.ShowFull(title, msg, yes, no, false, STR_KEYNAME_VIEWALERT_USER_GUIDE, OnUIViewAlertFinished);
        }

    }
    void ShowGameWin()
    {
        Debug.Log("ShowGameWin");

        string title = Language.main.GetString(AppString.STR_UIVIEWALERT_TITLE_GAME_FINISH);
        string msg = Language.main.GetString(AppString.STR_UIVIEWALERT_MSG_GAME_FINISH);
        string yes = Language.main.GetString(AppString.STR_UIVIEWALERT_YES_GAME_FINISH);
        string no = Language.main.GetString(AppString.STR_UIVIEWALERT_NO_GAME_FINISH);

        ViewAlertManager.main.ShowFull(title, msg, yes, no, false, STR_KEYNAME_VIEWALERT_GAME_FINISH, OnUIViewAlertFinished);

    }
    void OnUIViewAlertFinished(UIViewAlert alert, bool isYes)
    {

        if (STR_KEYNAME_VIEWALERT_GAME_FINISH == alert.keyName)
        {
            if (isYes)
            {
                GameManager.GotoNextLevelWithoutPlace();
            }
            else
            {

            }
        }


        if (STR_KEYNAME_VIEWALERT_GAME_FINISH == alert.keyName)
        {

            string pkey = AppString.STR_KEY_USER_GUIDE + Common.GetAppVersion();
            Common.SetBool(pkey, true);
        }


    }

    public override void TTSSpeechDidStart(string str)
    {
    }
    public override void TTSSpeechDidFinish(string str)
    {
        Debug.Log("GameLearnSound TTSSpeechDidFinish ");
        if (gameMode == GAME_MODE_LEARN)
        {
            if (isTTSSpeakTitle)
            {
                isTTSSpeakTitle = false;
                //tts之后播放声音 防止冲突
                PlayItemSound();
            }

        }
    }

    public override void OnClickBtnBack()
    {
        bool ret = Common.GetBool(AppString.STR_KEY_BACKGROUND_MUSIC);
        if (ret)
        {
            // Debug.Log("GameLearnSoudn OnDestroy");
            AudioPlay.main.Play();
        }
        base.OnClickBtnBack();
    }
    public void OnClickBtnPre()
    {
        GameManager.GotoPreLevel();
    }
    public void OnClickBtnNext()
    {
        GameManager.GotoNextLevel();
    }

    public void OnClickBtnSwitch()
    {
        GameManager.GotoNextLevel();
    }
}
