﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class UIHomeLearnSound : UIHomeBase
{
    //public GameObject objTopBar;
    public GameObject objParticleSystemMusic;
    public Image imageGoldBg;
    public Text textGold;
    public Button btnHistory;
    public Button btnLearn;
    public Button btnGuess;
    public Button btnMore;
    public GameObject objLayoutBtn;

    void Awake()
    {
        if (!AppVersion.appCheckHasFinished)
        {
            btnMore.gameObject.SetActive(false);
        }
        AppSceneBase.main.UpdateWorldBg(AppRes.IMAGE_HOME_BG);
        AppSceneBase.main.AddObjToMainWorld(objParticleSystemMusic);
    }
    // Use this for initialization
    void Start()
    {
        InitUI();
    }
    // Update is called once per frame
    void Update()
    {

        if (Device.isDeviceDidRotation)
        {

            LayOutChild();
        }
    }

    void InitUI()
    {


        string appname = Common.GetAppNameDisplay();
        TextName.text = appname;
        bool ret = Common.GetBool(AppString.STR_KEY_BACKGROUND_MUSIC);
        if (ret)
        {
            TTS.Speek(appname);
        }

        float animate_time = 16.0f;

        {
            ActionRotation360 actionRotation360 = btnLearn.gameObject.AddComponent<ActionRotation360>();
            actionRotation360.duration = animate_time;
        }
        {
            ActionRotation360 actionRotation360 = btnGuess.gameObject.AddComponent<ActionRotation360>();
            actionRotation360.duration = animate_time;
        }



        //iTween.RotateTo(btnLearn.gameObject, iTween.Hash("rotation", new Vector3(0, 0, 180), "time", 1.0f, "loopType", iTween.LoopType.loop, "easeType", iTween.EaseType.linear));
        //iTween.RotateTo(btnGuess.gameObject,iTween.Hash("rotation",new Vector3(0,0,90),"time",1.0f,"loopType",iTween.LoopType.loop,"easeType",iTween.EaseType.linear));
        //iTween.RotateBy(btnLearn.gameObject,iTween.Hash("amount",new Vector3(0,0,1.0f),"time",1.0f,"loopType",iTween.LoopType.loop));
        //iTween.RotateBy(btnLearn.gameObject, iTween.Hash("z", 0.5f, "delay", 1.0f,"loopType",iTween.LoopType.loop));
        LayOutChild();
    }

    void LayOutChild()
    {
        float x, y, w, h;
        Vector2 sizeCanvas = this.frame.size;
        //image name
        {
            RectTransform rctran = imageBgName.GetComponent<RectTransform>();

            int fontSize = TextName.fontSize;
            int r = fontSize / 2;
            w = Common.GetStringLength(TextName.text, AppString.STR_FONT_NAME, fontSize) + r * 2;
            h = fontSize * 1.5f;
            if (!Device.isLandscape)
            {
                h = fontSize * 2;
                if ((w + r * 2) > sizeCanvas.x)
                {
                    //显示成两行文字
                    w = w / 2 + r * 2;
                    h = h * 2;
                    // RectTransform rctranText = TextName.GetComponent<RectTransform>();
                    // float w_text = rctranText.sizeDelta.x;
                    // rctranText.sizeDelta = new Vector2(w_text, h);
                }
            }

            rctran.sizeDelta = new Vector2(w, h);
            x = 0;
            y = (sizeCanvas.y - topBarHeight) / 4;
            rctran.anchoredPosition = new Vector2(x, y);
        }


        {
            RectTransform rctran = objLayoutBtn.GetComponent<RectTransform>();
            x = 0;
            float h_play = 0;
            float offy = h_play / 2;
            float offy_bottom = 0;
            if (!Device.isLandscape)
            {

                GridLayoutGroup gridLayout = uiHomeAppCenter.GetComponent<GridLayoutGroup>();
                Vector2 cellSize = gridLayout.cellSize;
                offy_bottom = cellSize.y;
            }
            Debug.Log("offy_bottom=" + offy_bottom);
            y = -offy - (this.frame.height / 2 - offy - offy_bottom) / 2;
            rctran.anchoredPosition = new Vector2(x, y);
        }

        //iPhoneX
        // if (!Device.isLandscape)
        // {
        //     //
        //     RectTransform rctran = objTopBar.GetComponent<RectTransform>();
        //     Vector2 sizeDelta = rctran.sizeDelta;
        //     float ofty = Common.ScreenToCanvasHeigt(sizeCanvas, Device.heightSystemTopBar);
        //     rctran.offsetMax = new Vector2(rctran.offsetMax.x, rctran.offsetMax.y - ofty);
        //     //offsetMax 修改之后sizeDelta也会跟着变化，需要还原
        //     rctran.sizeDelta = sizeDelta;
        //     //Debug.Log("objTopBar rctran=" + rctran.rect + " offsetMin=" + rctran.offsetMin + " offsetMax=" + rctran.offsetMax + " sizeDelta=" + rctran.sizeDelta);
        // }


    }


    void UpdateGold()
    {


    }



    public void OnClickGold()
    {

    }
    public void OnClickBtnHistory()
    {

    }



    public void OnClickBtnLearn()
    {
        GotoGameByMode(UIGameLearnSound.GAME_MODE_LEARN);
    }
    public void OnClickBtnGuess()
    {
        GotoGameByMode(UIGameLearnSound.GAME_MODE_GUESS);
    }

    public void OnClickBtnBoard()
    {

    }

    void GotoGameByMode(int mode)
    {

        GameManager.gameMode = mode;
        GameManager.placeLevel = 0;
        //必须在placeLevel设置之后再设置gameLevel
        GameManager.gameLevel = 0;
        if (this.controller != null)
        {
            NaviViewController navi = this.controller.naviController;
            if (UIGameLearnSound.GAME_MODE_LEARN == mode)
            {
                navi.Push(PlaceViewController.main);
            }
            else
            {
                navi.Push(GuankaViewController.main);
            }
        }

    }
}
