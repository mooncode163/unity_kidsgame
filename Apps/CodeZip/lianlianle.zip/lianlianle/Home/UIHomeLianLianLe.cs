﻿using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;

public class UIHomeLianLianLe : UIHomeBase
{
    float timeAction;
    bool isActionFinish;   
    

    //public ActionHomeBtn actionBtnLearn;
    public void Awake()
    {
        base.Awake();
        // TextureUtil.UpdateRawImageTexture(imageBg, AppRes.IMAGE_HOME_BG, true);
        AppSceneBase.main.UpdateWorldBg(AppRes.IMAGE_HOME_BG);
        string appname = Common.GetAppNameDisplay();
        TextName.text = appname;
        timeAction = 0.3f;
        isActionFinish = false;

        // actionBtnLearn.gameObject.SetActive(Config.main.APP_FOR_KIDS);


        // actionBtnLearn.ptNormal = layoutBtn.GetItemPostion(0, 0);
        LoadPrefab();  
   
 
    }

    // Use this for initialization
    public void Start()
    {
        base.Start();
        isActionFinish = false;
        // RunActionImageName();
        //   actionBtnLearn.RunAction();
        LayOut();
        Invoke("LayOut",0.1f);

        OnUIDidFinish(0.5f);
    }

    void LoadPrefab()
    {
        float x, y, z;
      

    }
    // Update is called once per frame
    void Update()
    {
        UpdateBase();
    }
 
 
 
    public override void LayOut()
    {
    base.LayOut();
        Vector2 sizeCanvas = this.frame.size;
        float x = 0, y = 0, w = 0, h = 0;
       
 
    }


}
