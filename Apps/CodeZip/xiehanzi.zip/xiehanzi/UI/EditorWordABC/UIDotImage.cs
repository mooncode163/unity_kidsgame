using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIDotImage : UIView
{
    public UIImage imageDot;
    public UIText textTitle;
    public int index;
    public void UpdateItem(bool isSel)
    {
        
    }
}

