using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
public interface IUIDotImageDelegate
{
    void OnUIDotImageDidLongPress(UIDotImage ui);
}
public class UIDotImage : UIView
{
    public UIImage imageDot;
    public UIText textTitle;
    public int index;
    public bool isEditor;
    bool isTouchDown;
    private IUIDotImageDelegate _delegate;

    public IUIDotImageDelegate iDelegate
    {
        get { return _delegate; }
        set { _delegate = value; }
    }
    public void Awake()
    {
        base.Awake();
        UITouchEventWithMove ev = this.gameObject.AddComponent<UITouchEventWithMove>();
        ev.callBackTouch = OnUITouchEvent;
        isEditor = false;

    }
    public void Start()
    {
        base.Start();
        imageDot.UpdateImage(ImageRes.main.GetImage("EditorWordDot"));
        LayOut();


    }

    public void UpdateItem()
    {
        textTitle.text = index.ToString();
    }

    public void OnUITouchEvent(UITouchEvent ev, PointerEventData eventData, int status)
    {
        Debug.Log("OnUITouchEvent status=" + status);

        switch (status)
        {
            case UITouchEvent.STATUS_TOUCH_DOWN:
                {
                    isTouchDown = true;
                    break;
                }
            case UITouchEvent.STATUS_TOUCH_MOVE:
                {
                    if (isEditor && isTouchDown)
                    // if (isEditor)
                    {
                        this.transform.position = eventData.position;
                    }
                    break;
                }

            case UITouchEvent.STATUS_TOUCH_UP:
                {
                    isTouchDown = false;
                    break;
                }
            case UITouchEvent.STATUS_LongPress:
                {
                     isTouchDown = false;
                    if (iDelegate != null)
                    {
                        // isEditor = true;
                        iDelegate.OnUIDotImageDidLongPress(this);
                    }
                    break;
                }

        }

    }
}

