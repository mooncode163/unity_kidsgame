﻿<?php
/* 

*/


class WordItemInfo
{
    public $id;
    public $word;
    public $pinyin; //拼音
    public $zuci; //组词
    public $bushou; //部首
    public $bihua; //笔画
    public $audio; //
    public $gif; //
    public $mean; //含义
    public $date;
    public $addtime;
}
