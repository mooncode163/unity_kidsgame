public interface ISVGDrawableSeg {
  void Render(SVGGraphicsPath graphicsPath);
}
