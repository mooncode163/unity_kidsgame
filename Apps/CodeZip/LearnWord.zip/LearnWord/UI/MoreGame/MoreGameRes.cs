﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MoreGameRes
{
    public const string MATCH = "Match";
    public const string PINTU = "Pintu";
    public const string Book = "Book";
    public const string FreeWrite = "FreeWrite";
    public const string History = "History";
}
