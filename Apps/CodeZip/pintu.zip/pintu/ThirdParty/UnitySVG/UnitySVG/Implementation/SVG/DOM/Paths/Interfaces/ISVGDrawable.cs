public interface ISVGDrawable {
  void BeforeRender(SVGTransformList transformList);

  void Render();
}
